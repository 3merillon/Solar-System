import { earthVertexShaderSource, earthFragmentShaderSource, createEarthUniformSetup } from './planet_shaders/earth-shaders.js';
import { marsVertexShaderSource, marsFragmentShaderSource, createMarsUniformSetup } from './planet_shaders/mars-shaders.js';
import { venusVertexShaderSource, venusFragmentShaderSource, createVenusUniformSetup } from './planet_shaders/venus-shaders.js';
import { moonVertexShaderSource, moonFragmentShaderSource, createMoonUniformSetup } from './planet_shaders/moon-shaders.js';
import { mercuryVertexShaderSource, mercuryFragmentShaderSource, createMercuryUniformSetup } from './planet_shaders/mercury-shaders.js';
import { jupiterVertexShaderSource, jupiterFragmentShaderSource, createJupiterUniformSetup } from './planet_shaders/jupiter-shaders.js';
import { saturnVertexShaderSource, saturnFragmentShaderSource, createSaturnUniformSetup } from './planet_shaders/saturn-shaders.js';
import { uranusVertexShaderSource, uranusFragmentShaderSource, createUranusUniformSetup } from './planet_shaders/uranus-shaders.js';
import { neptuneVertexShaderSource, neptuneFragmentShaderSource, createNeptuneUniformSetup } from './planet_shaders/neptune-shaders.js';
import { plutoVertexShaderSource, plutoFragmentShaderSource, createPlutoUniformSetup } from './planet_shaders/pluto-shaders.js';
import { phobosVertexShaderSource, phobosFragmentShaderSource, createPhobosUniformSetup } from './planet_shaders/phobos-shaders.js';
import { deimosVertexShaderSource, deimosFragmentShaderSource, createDeimosUniformSetup } from './planet_shaders/deimos-shaders.js';

export function setupPlanetShaders(shaderManager) {
    console.log('Setting up custom planet shaders...');
    
    // Register Earth shader
    const earthSuccess = shaderManager.registerCustomShader(
        'earth',
        earthVertexShaderSource,
        earthFragmentShaderSource,
        createEarthUniformSetup()
    );
    
    // Register Mars shader
    const marsSuccess = shaderManager.registerCustomShader(
        'mars',
        marsVertexShaderSource,
        marsFragmentShaderSource,
        createMarsUniformSetup()
    );

    // Register Phobos shader
    const phobosSuccess = shaderManager.registerCustomShader(
        'phobos',
        phobosVertexShaderSource,
        phobosFragmentShaderSource,
        createPhobosUniformSetup()
    );

    // Register Deimos shader
    const deimosSuccess = shaderManager.registerCustomShader(
        'deimos',
        deimosVertexShaderSource,
        deimosFragmentShaderSource,
        createDeimosUniformSetup()
    );
    
    // Register Venus shader
    const venusSuccess = shaderManager.registerCustomShader(
        'venus',
        venusVertexShaderSource,
        venusFragmentShaderSource,
        createVenusUniformSetup()
    );
    
    // Register Moon shader
    const moonSuccess = shaderManager.registerCustomShader(
        'moon',
        moonVertexShaderSource,
        moonFragmentShaderSource,
        createMoonUniformSetup()
    );
    
    // Mercury
    const mercurySuccess = shaderManager.registerCustomShader(
        'mercury',
        mercuryVertexShaderSource,
        mercuryFragmentShaderSource,
        createMercuryUniformSetup()
    );
    // Jupiter
    const jupiterSuccess = shaderManager.registerCustomShader(
        'jupiter',
        jupiterVertexShaderSource,
        jupiterFragmentShaderSource,
        createJupiterUniformSetup()
    );
    // Saturn
    const saturnSuccess = shaderManager.registerCustomShader(
        'saturn',
        saturnVertexShaderSource,
        saturnFragmentShaderSource,
        createSaturnUniformSetup()
    );
    // Uranus
    const uranusSuccess = shaderManager.registerCustomShader(
        'uranus',
        uranusVertexShaderSource,
        uranusFragmentShaderSource,
        createUranusUniformSetup()
    );
    // Neptune
    const neptuneSuccess = shaderManager.registerCustomShader(
        'neptune',
        neptuneVertexShaderSource,
        neptuneFragmentShaderSource,
        createNeptuneUniformSetup()
    );
    // Pluto
    const plutoSuccess = shaderManager.registerCustomShader(
        'pluto',
        plutoVertexShaderSource,
        plutoFragmentShaderSource,
        createPlutoUniformSetup()
    );
    
    console.log('Planet shader registration results:', {
        earth: earthSuccess,
        mars: marsSuccess,
        phobos: phobosSuccess,
        deimos: deimosSuccess,
        venus: venusSuccess,
        moon: moonSuccess,
        mercury: mercurySuccess,
        jupiter: jupiterSuccess,
        saturn: saturnSuccess,
        uranus: uranusSuccess,
        neptune: neptuneSuccess,
        pluto: plutoSuccess
    });
    return earthSuccess && marsSuccess && phobosSuccess && deimosSuccess && venusSuccess && moonSuccess &&
        mercurySuccess && jupiterSuccess && saturnSuccess &&
        uranusSuccess && neptuneSuccess && plutoSuccess;
}